# PBIdentifyAPIValidateMailingAddressPremiumServiceApi

All URIs are relative to *https://api-qa.pitneybowes.com/identify*

Method | HTTP request | Description
------------- | ------------- | -------------
[**validateMailingAddressPremium**](PBIdentifyAPIValidateMailingAddressPremiumServiceApi.md#validatemailingaddresspremium) | **POST** /identifyaddress/v1/rest/validatemailingaddresspremium/results.json | 


# **validateMailingAddressPremium**
```objc
-(NSNumber*) validateMailingAddressPremiumWithInputAddress: (PBValidateMailingAddressPremiumRequest*) inputAddress
        completionHandler: (void (^)(PBValidateMailingAddressPremiumResponse* output, NSError* error)) handler;
```



ValidateMailing AddressPremium expands on the ValidateMailingAddressPro service by adding premium address data sources to get the best address validation result possible.

### Example 
```objc
PBConfiguration *apiConfig = [PBConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: apiKey)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


PBValidateMailingAddressPremiumRequest* inputAddress = [[PBValidateMailingAddressPremiumRequest alloc] init]; // 

PBIdentifyAPIValidateMailingAddressPremiumServiceApi*apiInstance = [[PBIdentifyAPIValidateMailingAddressPremiumServiceApi alloc] init];

[apiInstance validateMailingAddressPremiumWithInputAddress:inputAddress
          completionHandler: ^(PBValidateMailingAddressPremiumResponse* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling PBIdentifyAPIValidateMailingAddressPremiumServiceApi->validateMailingAddressPremium: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **inputAddress** | [**PBValidateMailingAddressPremiumRequest***](PBValidateMailingAddressPremiumRequest*.md)|  | 

### Return type

[**PBValidateMailingAddressPremiumResponse***](PBValidateMailingAddressPremiumResponse.md)

### Authorization

[apiKey](../README.md#apiKey)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

