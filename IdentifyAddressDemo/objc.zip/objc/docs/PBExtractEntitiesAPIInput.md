# PBExtractEntitiesAPIInput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**row** | [**NSArray&lt;PBExtractEntitiesAPIInputRow&gt;***](PBExtractEntitiesAPIInputRow.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


