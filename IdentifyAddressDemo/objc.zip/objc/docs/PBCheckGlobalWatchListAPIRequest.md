# PBCheckGlobalWatchListAPIRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**options** | [**PBCheckGlobalWatchListAPIOptions***](PBCheckGlobalWatchListAPIOptions.md) |  | [optional] 
**input** | [**PBCheckGlobalWatchListAPIInput***](PBCheckGlobalWatchListAPIInput.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


