# PBGetPostalCodesAPIOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**outputCityType** | **NSString*** | Output CityType. | [optional] [default to @"N"]
**outputVanityCity** | **NSString*** | Output VanityCity. | [optional] [default to @"N"]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


