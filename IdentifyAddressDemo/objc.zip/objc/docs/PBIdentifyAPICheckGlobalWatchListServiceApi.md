# PBIdentifyAPICheckGlobalWatchListServiceApi

All URIs are relative to *https://api-qa.pitneybowes.com/identify*

Method | HTTP request | Description
------------- | ------------- | -------------
[**checkGlobalWatchList**](PBIdentifyAPICheckGlobalWatchListServiceApi.md#checkglobalwatchlist) | **POST** /identifyrisk/v1/rest/checkglobalwatchlist/results.json | 


# **checkGlobalWatchList**
```objc
-(NSNumber*) checkGlobalWatchListWithInputRecord: (PBCheckGlobalWatchListAPIRequest*) inputRecord
        completionHandler: (void (^)(PBCheckGlobalWatchListAPIResponse* output, NSError* error)) handler;
```



CheckGlobalWatchListAPI helps ensure compliance with your Anti-Money Laundering (AML) and Know Your Customer (KYC) obligations by checking whether your customer is a known or suspected money laundering, terrorist, or other person considered high risk to your business..

### Example 
```objc
PBConfiguration *apiConfig = [PBConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: apiKey)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


PBCheckGlobalWatchListAPIRequest* inputRecord = [[PBCheckGlobalWatchListAPIRequest alloc] init]; // 

PBIdentifyAPICheckGlobalWatchListServiceApi*apiInstance = [[PBIdentifyAPICheckGlobalWatchListServiceApi alloc] init];

[apiInstance checkGlobalWatchListWithInputRecord:inputRecord
          completionHandler: ^(PBCheckGlobalWatchListAPIResponse* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling PBIdentifyAPICheckGlobalWatchListServiceApi->checkGlobalWatchList: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **inputRecord** | [**PBCheckGlobalWatchListAPIRequest***](PBCheckGlobalWatchListAPIRequest*.md)|  | 

### Return type

[**PBCheckGlobalWatchListAPIResponse***](PBCheckGlobalWatchListAPIResponse.md)

### Authorization

[apiKey](../README.md#apiKey)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

