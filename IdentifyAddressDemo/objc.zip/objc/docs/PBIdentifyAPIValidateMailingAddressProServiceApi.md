# PBIdentifyAPIValidateMailingAddressProServiceApi

All URIs are relative to *https://api-qa.pitneybowes.com/identify*

Method | HTTP request | Description
------------- | ------------- | -------------
[**validateMailingAddressPro**](PBIdentifyAPIValidateMailingAddressProServiceApi.md#validatemailingaddresspro) | **POST** /identifyaddress/v1/rest/validatemailingaddresspro/results.json | 


# **validateMailingAddressPro**
```objc
-(NSNumber*) validateMailingAddressProWithInputAddress: (PBValidateMailingAddressProRequest*) inputAddress
        completionHandler: (void (^)(PBValidateMailingAddressProResponse* output, NSError* error)) handler;
```



ValidateMailingAddressPro builds upon the ValidateMailingAddress service by using additional address databases so it can provide enhanced detail.

### Example 
```objc
PBConfiguration *apiConfig = [PBConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: apiKey)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


PBValidateMailingAddressProRequest* inputAddress = [[PBValidateMailingAddressProRequest alloc] init]; // 

PBIdentifyAPIValidateMailingAddressProServiceApi*apiInstance = [[PBIdentifyAPIValidateMailingAddressProServiceApi alloc] init];

[apiInstance validateMailingAddressProWithInputAddress:inputAddress
          completionHandler: ^(PBValidateMailingAddressProResponse* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling PBIdentifyAPIValidateMailingAddressProServiceApi->validateMailingAddressPro: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **inputAddress** | [**PBValidateMailingAddressProRequest***](PBValidateMailingAddressProRequest*.md)|  | 

### Return type

[**PBValidateMailingAddressProResponse***](PBValidateMailingAddressProResponse.md)

### Authorization

[apiKey](../README.md#apiKey)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

