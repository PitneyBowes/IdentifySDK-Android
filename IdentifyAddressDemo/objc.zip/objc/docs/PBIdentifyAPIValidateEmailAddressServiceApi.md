# PBIdentifyAPIValidateEmailAddressServiceApi

All URIs are relative to *https://api-qa.pitneybowes.com/identify*

Method | HTTP request | Description
------------- | ------------- | -------------
[**validateEmailAddress**](PBIdentifyAPIValidateEmailAddressServiceApi.md#validateemailaddress) | **POST** /identifyemail/v1/rest/validateemailaddress/results.json | 


# **validateEmailAddress**
```objc
-(NSNumber*) validateEmailAddressWithInputEmailAddress: (PBValidateEmailAddressAPIRequest*) inputEmailAddress
        completionHandler: (void (^)(PBValidateEmailAddressAPIResponse* output, NSError* error)) handler;
```



ValidateEmailAddress corrects and validates email addresses to protect your database from invalid, toxic and undesirable email addresses.

### Example 
```objc
PBConfiguration *apiConfig = [PBConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: apiKey)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


PBValidateEmailAddressAPIRequest* inputEmailAddress = [[PBValidateEmailAddressAPIRequest alloc] init]; // 

PBIdentifyAPIValidateEmailAddressServiceApi*apiInstance = [[PBIdentifyAPIValidateEmailAddressServiceApi alloc] init];

[apiInstance validateEmailAddressWithInputEmailAddress:inputEmailAddress
          completionHandler: ^(PBValidateEmailAddressAPIResponse* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling PBIdentifyAPIValidateEmailAddressServiceApi->validateEmailAddress: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **inputEmailAddress** | [**PBValidateEmailAddressAPIRequest***](PBValidateEmailAddressAPIRequest*.md)|  | 

### Return type

[**PBValidateEmailAddressAPIResponse***](PBValidateEmailAddressAPIResponse.md)

### Authorization

[apiKey](../README.md#apiKey)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

