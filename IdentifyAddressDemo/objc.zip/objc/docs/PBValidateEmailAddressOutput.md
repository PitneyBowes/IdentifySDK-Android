# PBValidateEmailAddressOutput

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userFields** | [**PBUserFields***](PBUserFields.md) |  | [optional] 
**eMAIL** | **NSString*** |  | [optional] 
**fINDING** | **NSString*** |  | [optional] 
**cOMMENT** | **NSString*** |  | [optional] 
**cOMMENTCODE** | **NSString*** |  | [optional] 
**sUGGEMAIL** | **NSString*** |  | [optional] 
**sUGGCOMMENT** | **NSString*** |  | [optional] 
**eRRORRESPONSE** | **NSString*** |  | [optional] 
**eRROR** | **NSString*** |  | [optional] 
**status** | **NSString*** |  | [optional] 
**statusCode** | **NSString*** |  | [optional] 
**statusDescription** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


