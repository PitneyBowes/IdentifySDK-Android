# PBIdentifyAPIGetCityStateProvinceServiceApi

All URIs are relative to *https://api-qa.pitneybowes.com/identify*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getCityStateProvince**](PBIdentifyAPIGetCityStateProvinceServiceApi.md#getcitystateprovince) | **POST** /identifyaddress/v1/rest/getcitystateprovince/results.json | 


# **getCityStateProvince**
```objc
-(NSNumber*) getCityStateProvinceWithInputAddress: (PBGetCityStateProvinceAPIRequest*) inputAddress
        completionHandler: (void (^)(PBGetCityStateProvinceAPIResponse* output, NSError* error)) handler;
```



GetCityStateProvince returns a city and state/province for a given input postal code for U.S. and Canadian addresses.

### Example 
```objc
PBConfiguration *apiConfig = [PBConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: apiKey)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


PBGetCityStateProvinceAPIRequest* inputAddress = [[PBGetCityStateProvinceAPIRequest alloc] init]; // 

PBIdentifyAPIGetCityStateProvinceServiceApi*apiInstance = [[PBIdentifyAPIGetCityStateProvinceServiceApi alloc] init];

[apiInstance getCityStateProvinceWithInputAddress:inputAddress
          completionHandler: ^(PBGetCityStateProvinceAPIResponse* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling PBIdentifyAPIGetCityStateProvinceServiceApi->getCityStateProvince: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **inputAddress** | [**PBGetCityStateProvinceAPIRequest***](PBGetCityStateProvinceAPIRequest*.md)|  | 

### Return type

[**PBGetCityStateProvinceAPIResponse***](PBGetCityStateProvinceAPIResponse.md)

### Authorization

[apiKey](../README.md#apiKey)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

