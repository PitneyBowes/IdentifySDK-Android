# PBExtractEntitiesAPIOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entityList** | **NSString*** | Specifies the type of data you want to extract from the unstructured string | [optional] [default to @"Person,Address"]
**outputEntityCount** | **NSString*** | Specifies whether to return a count of how many times a particular entity occurred in the output | [optional] [default to @"false"]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


