# PBValidateMailingAddressPremiumRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**options** | [**PBValidateMailingAddressPremiumOptions***](PBValidateMailingAddressPremiumOptions.md) |  | [optional] 
**input** | [**PBValidateMailingAddressPremiumInput***](PBValidateMailingAddressPremiumInput.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


