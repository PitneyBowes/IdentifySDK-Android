# PBIdentifyAPIValidateMailingAddressServiceApi

All URIs are relative to *https://api-qa.pitneybowes.com/identify*

Method | HTTP request | Description
------------- | ------------- | -------------
[**validateMailingAddress**](PBIdentifyAPIValidateMailingAddressServiceApi.md#validatemailingaddress) | **POST** /identifyaddress/v1/rest/validatemailingaddress/results.json | 


# **validateMailingAddress**
```objc
-(NSNumber*) validateMailingAddressWithInputAddress: (PBValidateMailingAddressRequest*) inputAddress
        completionHandler: (void (^)(PBValidateMailingAddressResponse* output, NSError* error)) handler;
```



ValidateMailingAddress analyses and compares the input addresses against the known address databases around the world to output a standardized detail.

### Example 
```objc
PBConfiguration *apiConfig = [PBConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: apiKey)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


PBValidateMailingAddressRequest* inputAddress = [[PBValidateMailingAddressRequest alloc] init]; // 

PBIdentifyAPIValidateMailingAddressServiceApi*apiInstance = [[PBIdentifyAPIValidateMailingAddressServiceApi alloc] init];

[apiInstance validateMailingAddressWithInputAddress:inputAddress
          completionHandler: ^(PBValidateMailingAddressResponse* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling PBIdentifyAPIValidateMailingAddressServiceApi->validateMailingAddress: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **inputAddress** | [**PBValidateMailingAddressRequest***](PBValidateMailingAddressRequest*.md)|  | 

### Return type

[**PBValidateMailingAddressResponse***](PBValidateMailingAddressResponse.md)

### Authorization

[apiKey](../README.md#apiKey)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

