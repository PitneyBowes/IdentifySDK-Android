# PBGetPostalCodesAPIRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**options** | [**PBGetPostalCodesAPIOptions***](PBGetPostalCodesAPIOptions.md) |  | [optional] 
**input** | [**PBGetPostalCodesAPIInput***](PBGetPostalCodesAPIInput.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


