# PBGetCityStateProvinceAPIOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**outputVanityCity** | **NSString*** | Output VanityCity. | [optional] [default to @"N"]
**performCanadianProcessing** | **NSString*** | PerformCanadianProcessing. | [optional] [default to @"Y"]
**maximumResults** | **NSString*** | MaximumResults. | [optional] [default to @"10"]
**performUSProcessing** | **NSString*** | PerformUSProcessing. | [optional] [default to @"Y"]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


