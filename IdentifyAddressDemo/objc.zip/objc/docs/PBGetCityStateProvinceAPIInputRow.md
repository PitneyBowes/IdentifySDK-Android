# PBGetCityStateProvinceAPIInputRow

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userFields** | [**PBUserFields***](PBUserFields.md) |  | [optional] 
**postalCode** | **NSString*** | The validated ZIP Code� or postal code. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


