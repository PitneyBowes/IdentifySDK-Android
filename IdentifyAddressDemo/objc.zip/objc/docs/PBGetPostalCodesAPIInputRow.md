# PBGetPostalCodesAPIInputRow

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userFields** | [**PBUserFields***](PBUserFields.md) |  | [optional] 
**city** | **NSString*** | The city name. | [optional] 
**stateProvince** | **NSString*** | The state or province. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


