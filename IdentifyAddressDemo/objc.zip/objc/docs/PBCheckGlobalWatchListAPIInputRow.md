# PBCheckGlobalWatchListAPIInputRow

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userFields** | [**PBUserFields***](PBUserFields.md) |  | [optional] 
**addressLine1** | **NSString*** |  | [optional] 
**addressLine2** | **NSString*** |  | [optional] 
**addressLine3** | **NSString*** |  | [optional] 
**citizenship** | **NSString*** |  | [optional] 
**country** | **NSString*** |  | [optional] 
**dOB** | **NSString*** |  | [optional] 
**firstName** | **NSString*** |  | [optional] 
**iDNumber** | **NSString*** |  | [optional] 
**lastName** | **NSString*** |  | [optional] 
**name** | **NSString*** |  | [optional] 
**nationality** | **NSString*** |  | [optional] 
**placeOfBirth** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


