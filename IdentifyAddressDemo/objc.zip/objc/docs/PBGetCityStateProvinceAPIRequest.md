# PBGetCityStateProvinceAPIRequest

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**options** | [**PBGetCityStateProvinceAPIOptions***](PBGetCityStateProvinceAPIOptions.md) |  | [optional] 
**input** | [**PBGetCityStateProvinceAPIInput***](PBGetCityStateProvinceAPIInput.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


