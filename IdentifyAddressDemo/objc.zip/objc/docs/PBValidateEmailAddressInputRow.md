# PBValidateEmailAddressInputRow

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userFields** | [**PBUserFields***](PBUserFields.md) |  | [optional] 
**rtc** | **NSString*** |  | [optional] 
**bogus** | **NSString*** |  | [optional] 
**role** | **NSString*** |  | [optional] 
**emps** | **NSString*** |  | [optional] 
**fccwireless** | **NSString*** |  | [optional] 
**language** | **NSString*** |  | [optional] 
**complain** | **NSString*** |  | [optional] 
**disposable** | **NSString*** |  | [optional] 
**atc** | **NSString*** |  | [optional] 
**emailAddress** | **NSString*** |  | [optional] 
**rtcTimeout** | **NSString*** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


