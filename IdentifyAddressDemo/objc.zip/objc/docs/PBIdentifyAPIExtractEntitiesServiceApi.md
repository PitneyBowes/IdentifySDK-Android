# PBIdentifyAPIExtractEntitiesServiceApi

All URIs are relative to *https://api-qa.pitneybowes.com/identify*

Method | HTTP request | Description
------------- | ------------- | -------------
[**extractEntities**](PBIdentifyAPIExtractEntitiesServiceApi.md#extractentities) | **POST** /identifyentity/v1/rest/extractentities/results.json | 


# **extractEntities**
```objc
-(NSNumber*) extractEntitiesWithInputRecord: (PBExtractEntitiesAPIRequest*) inputRecord
        completionHandler: (void (^)(PBExtractEntitiesAPIResponse* output, NSError* error)) handler;
```



ExtractEntities API extracts and identifies entities (distinct pieces of identifiable information, such as personal names, business names, mailing address, email address, and phone number) from a string of unstructured data.

### Example 
```objc
PBConfiguration *apiConfig = [PBConfiguration sharedConfig];

// Configure OAuth2 access token for authorization: (authentication scheme: apiKey)
[apiConfig setAccessToken:@"YOUR_ACCESS_TOKEN"];


PBExtractEntitiesAPIRequest* inputRecord = [[PBExtractEntitiesAPIRequest alloc] init]; // 

PBIdentifyAPIExtractEntitiesServiceApi*apiInstance = [[PBIdentifyAPIExtractEntitiesServiceApi alloc] init];

[apiInstance extractEntitiesWithInputRecord:inputRecord
          completionHandler: ^(PBExtractEntitiesAPIResponse* output, NSError* error) {
                        if (output) {
                            NSLog(@"%@", output);
                        }
                        if (error) {
                            NSLog(@"Error calling PBIdentifyAPIExtractEntitiesServiceApi->extractEntities: %@", error);
                        }
                    }];
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **inputRecord** | [**PBExtractEntitiesAPIRequest***](PBExtractEntitiesAPIRequest*.md)|  | 

### Return type

[**PBExtractEntitiesAPIResponse***](PBExtractEntitiesAPIResponse.md)

### Authorization

[apiKey](../README.md#apiKey)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

