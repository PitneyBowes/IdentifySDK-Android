# PBValidateMailingAddressOptions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**outputCasing** | **NSString*** | Specify the casing of the output data. | [optional] [default to @"M"]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


