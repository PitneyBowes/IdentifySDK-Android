# PBValidateMailingAddressProResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**output** | [**NSArray&lt;PBValidateMailingAddressProOutput&gt;***](PBValidateMailingAddressProOutput.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


