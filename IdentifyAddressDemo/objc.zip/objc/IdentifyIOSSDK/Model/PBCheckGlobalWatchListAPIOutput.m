#import "PBCheckGlobalWatchListAPIOutput.h"

@implementation PBCheckGlobalWatchListAPIOutput

- (instancetype)init {
  self = [super init];
  if (self) {
    // initialize property's default value, if any
    
  }
  return self;
}


/**
 * Maps json key to property name.
 * This method is used by `JSONModel`.
 */
+ (JSONKeyMapper *)keyMapper {
  return [[JSONKeyMapper alloc] initWithDictionary:@{ @"user_fields": @"userFields", @"OverallRiskLevel": @"overallRiskLevel", @"SanctionedCountryIdentified": @"sanctionedCountryIdentified", @"Status": @"status", @"Status.Code": @"statusCode", @"Status.Description": @"statusDescription", @"AddressLine1": @"addressLine1", @"AddressLine2": @"addressLine2", @"AddressLine3": @"addressLine3", @"Citizenship": @"citizenship", @"Country": @"country", @"DOB": @"dOB", @"FirstName": @"firstName", @"IDNumber": @"iDNumber", @"LastName": @"lastName", @"Name": @"name", @"Nationality": @"nationality", @"PlaceOfBirth": @"placeOfBirth", @"City": @"city", @"EntryID": @"entryID", @"InputFilteredFirstName": @"inputFilteredFirstName", @"InputFilteredLastName": @"inputFilteredLastName", @"InputFilteredName": @"inputFilteredName", @"InputFirstName": @"inputFirstName", @"InputLastName": @"inputLastName", @"InputName": @"inputName", @"ListType": @"listType", @"NameMatchIdentified": @"nameMatchIdentified", @"NameProvided": @"nameProvided", @"AddressProvided": @"addressProvided", @"IDNumberProvided": @"iDNumberProvided", @"InputAddressLine1": @"inputAddressLine1", @"InputAddressLine2": @"inputAddressLine2", @"InputAddressLine3": @"inputAddressLine3", @"InputCountry": @"inputCountry", @"InputIDNumber": @"inputIDNumber", @"InputDOB": @"inputDOB", @"InputNationality": @"inputNationality", @"InputCitizenship": @"inputCitizenship", @"InputPlaceOfBirth": @"inputPlaceOfBirth", @"AddressMatchIdentified": @"addressMatchIdentified", @"AddressScore": @"addressScore", @"FirmName": @"firmName", @"IDNumberMatchIdentified": @"iDNumberMatchIdentified", @"IDNumberScore": @"iDNumberScore", @"CitizenshipScore": @"citizenshipScore", @"CitizenshipMatchIdentified": @"citizenshipMatchIdentified", @"DOBScore": @"dOBScore", @"DOBMatchIdentified": @"dOBMatchIdentified", @"NationalityScore": @"nationalityScore", @"NationalityMatchIdentified": @"nationalityMatchIdentified", @"PlaceOfBirthScore": @"placeOfBirthScore", @"PlaceOfBirthMatchIdentified": @"placeOfBirthMatchIdentified", @"CitizenshipProvided": @"citizenshipProvided", @"DOBProvided": @"dOBProvided", @"NationalityProvided": @"nationalityProvided", @"PlaceOfBirthProvided": @"placeOfBirthProvided", @"NameScore": @"nameScore", @"MatchStatus": @"matchStatus" }];
}

/**
 * Indicates whether the property with the given name is optional.
 * If `propertyName` is optional, then return `YES`, otherwise return `NO`.
 * This method is used by `JSONModel`.
 */
+ (BOOL)propertyIsOptional:(NSString *)propertyName {

  NSArray *optionalProperties = @[@"userFields", @"overallRiskLevel", @"sanctionedCountryIdentified", @"status", @"statusCode", @"statusDescription", @"addressLine1", @"addressLine2", @"addressLine3", @"citizenship", @"country", @"dOB", @"firstName", @"iDNumber", @"lastName", @"name", @"nationality", @"placeOfBirth", @"city", @"entryID", @"inputFilteredFirstName", @"inputFilteredLastName", @"inputFilteredName", @"inputFirstName", @"inputLastName", @"inputName", @"listType", @"nameMatchIdentified", @"nameProvided", @"addressProvided", @"iDNumberProvided", @"inputAddressLine1", @"inputAddressLine2", @"inputAddressLine3", @"inputCountry", @"inputIDNumber", @"inputDOB", @"inputNationality", @"inputCitizenship", @"inputPlaceOfBirth", @"addressMatchIdentified", @"addressScore", @"firmName", @"iDNumberMatchIdentified", @"iDNumberScore", @"citizenshipScore", @"citizenshipMatchIdentified", @"dOBScore", @"dOBMatchIdentified", @"nationalityScore", @"nationalityMatchIdentified", @"placeOfBirthScore", @"placeOfBirthMatchIdentified", @"citizenshipProvided", @"dOBProvided", @"nationalityProvided", @"placeOfBirthProvided", @"nameScore", @"matchStatus"];
  return [optionalProperties containsObject:propertyName];
}

@end
